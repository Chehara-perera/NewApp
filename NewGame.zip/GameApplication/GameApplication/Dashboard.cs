﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameApplication
{
   
    public partial class Dashboard : Form
    {
        public static string user = "";
        public static string SetValueForText3 = "";
        public Dashboard()
        {
            InitializeComponent();
            user = Login.SetValueForText1;
        }

        private void btn_eight_queen_puzzle_Click(object sender, EventArgs e)
        {
            SetValueForText3 = user;
            Form1 form = new Form1();
            form.Show();
        }

        private void btn_encode_decode_Click(object sender, EventArgs e)
        {
            SetValueForText3 = user;
            MainForm mainform = new MainForm();
            mainform.Show();
        }

        private void btn_minimum_connectors_Click(object sender, EventArgs e)
        {
            SetValueForText3 = user;
            Minimum_connectors min = new Minimum_connectors();
            min.Show();
        }

        private void btn_tic_tac_toe_Click(object sender, EventArgs e)
        {
            SetValueForText3 = user;
            TicTacToe tic = new TicTacToe();
            tic.Show();
        }

        private void btn_shortest_path_Click(object sender, EventArgs e)
        {
            SetValueForText3 = user;
            FindTheShortestPath find = new FindTheShortestPath();
            find.Show();

        }
    }
}
