﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace GameApplication
{
    public partial class Login : Form
    {
        private string connectionString = "Data Source=LAPTOP-ATG56U89;Initial Catalog=GameApp;Integrated Security=True";
       // private object username;
        public static string SetValueForText1 = "";

        public Login()
        {
            InitializeComponent();

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            SetValueForText1 = txtUsername.Text;

            this.Hide();
            Dashboard dash = new Dashboard();
            dash.Show();


            if (IsValidLogin(username, password))
            {
                MessageBox.Show(this,"Login successful!","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);
                
            }
            else
            {
                MessageBox.Show(this,"Invalid username or password. Please try again.","Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private bool IsValidLogin(string username, string password)
        {
            string query = "SELECT Password FROM Game_user WHERE Username=@Username";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);

                    connection.Open();

                    string hashedPassword = (string)command.ExecuteScalar();

                    if (hashedPassword == null)
                        return false;

                    bool isValidPassword = VerifyPassword(password, hashedPassword);

                    return isValidPassword;
                }
            }
        }

        private bool VerifyPassword(string password, string hashedPassword)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));

                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }

                string hashedInputPassword = builder.ToString();

                return StringComparer.OrdinalIgnoreCase.Compare(hashedInputPassword, hashedPassword) == 0;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();
        }
    }
}